# Lưu trữ và tìm kiếm ảnh động vật bốn chân

Mã nguồn đã được tách vào `tools/image_processing/`, `tools/segmentation/` và
`tools/validation/`; kiểm thử ở `tests/`. Dữ liệu và kết quả vẫn dùng đường dẫn cũ.

[Báo cáo chuyển mã, lệnh chạy và kiểm thử](docs/source_migration.md).
[Kế hoạch sắp xếp toàn dự án](docs/migration_plan.md).

Chạy từ thư mục gốc BTL:

```sh
python3 tools/image_processing/auto_crop.py --help
python3 tools/image_processing/review_images.py --help
.venv/bin/python tools/segmentation/run_grabcut.py --help
.venv/bin/python tools/segmentation/edit_masks.py --help
.venv/bin/python tools/validation/audit_images.py --help
```

Các lệnh `--help` chỉ hiển thị cách dùng. Công cụ ảnh tiếp tục dùng môi trường ở
`bo_tool_anh_576x384/.venv/`; các công cụ GrabCut/editor/sync dùng môi trường gốc `.venv/`.
