#!/usr/bin/env python3
"""Verify the new queue results and confirm old/source files were preserved."""
import csv
import json
from pathlib import Path

import numpy as np
from PIL import Image

import tao_lai_mask_can_sua as batch


def main():
    output = batch.BASE / 'mask_moi_can_sua'
    inventory = json.loads((batch.BASE / 'mask_moi_can_sua_truoc_khi_chay.json').read_text())
    changed = []
    for relative, before in inventory.items():
        path = batch.ROOT / relative
        if not path.is_file():
            changed.append(relative)
            continue
        stat = path.stat()
        if stat.st_size != before['size'] or stat.st_mtime_ns != before['mtime_ns'] or batch.sha256(path) != before['sha256']:
            changed.append(relative)
    assert not changed, f'Protected files changed: {changed[:10]}'
    with (output / 'manifest.csv').open(newline='') as stream:
        rows = list(csv.DictReader(stream))
    expected = {p.name for p in (batch.PREVIOUS / 'overlays/cần sửa').iterdir() if p.is_file() and p.suffix.lower() == '.png'}
    assert len(rows) == len(expected) == len({r['filename'] for r in rows})
    assert {r['filename'] + '.png' for r in rows} == expected
    sheets = set()
    for row in rows:
        assert row['status'] == 'success', (row['filename'], row['error'])
        assert row['review_status'] == 'chua_duyet'
        assert (int(row['width']), int(row['height'])) == (576, 384)
        with Image.open(output / row['mask_path']) as image:
            assert image.format == 'PNG' and image.mode == 'L' and image.size == (576, 384)
            mask = np.asarray(image)
        assert set(np.unique(mask)).issubset({0, 255})
        pixels = int(np.count_nonzero(mask))
        assert pixels == int(row['mask_pixels'])
        assert int(row['total_pixels']) == mask.size
        assert abs(float(row['mask_ratio']) - pixels / mask.size) < 1e-12
        assert batch.sha256(Path(row['source_path'])) == row['source_sha256']
        with Image.open(row['source_path']) as image:
            source = image.convert('RGB')
        with Image.open(output / row['overlay_path']) as image:
            assert image.format == 'PNG' and image.size == (576, 384)
            assert np.array_equal(np.asarray(image), np.asarray(batch.overlay(source, mask)))
        for artifact in ('mask', 'overlay'):
            assert batch.sha256(output / row[artifact + '_path']) == row[artifact + '_sha256']
        for artifact in ('previous_mask', 'previous_overlay'):
            assert batch.sha256(Path(row[artifact + '_path'])) == row[artifact + '_sha256']
        with Image.open(row['previous_mask_path']) as image:
            previous = np.asarray(image)
        assert abs(float(row['changed_pixel_fraction']) - float(np.mean((mask != 0) != (previous != 0)))) < 1e-12
        sheets.add(row['quicklook_path'])
    for sheet in sheets:
        with Image.open(output / sheet) as image:
            image.verify()
    with (output / 'errors.csv').open(newline='') as stream:
        errors = list(csv.DictReader(stream))
    result = dict(images_verified=len(rows), mask_pngs=len(rows), overlay_pngs=len(rows),
                  contact_sheets=len(sheets), protected_files_unchanged=len(inventory),
                  logged_errors=len(errors), processing_size='576x384',
                  all_review_status='chua_duyet', verified_at=batch.now(), note=batch.NOTE)
    batch.write_json(output / 'verification.json', result)
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
