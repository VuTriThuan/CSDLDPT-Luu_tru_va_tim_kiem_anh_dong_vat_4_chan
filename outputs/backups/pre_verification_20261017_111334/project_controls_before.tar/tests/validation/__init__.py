"""BTL tests validation package."""
