"""BTL tools validation package."""
